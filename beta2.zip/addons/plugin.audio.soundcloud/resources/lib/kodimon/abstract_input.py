def on_keyboard_input(title, default='', hidden=False):
    raise NotImplementedError()